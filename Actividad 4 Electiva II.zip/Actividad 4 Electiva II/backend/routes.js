import { Router } from "express";
import fs from "fs";

const router = Router();
const DB_PATH = "database.json";

function readDB() {
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// Rutas en español para coincidir con el frontend
router.get("/productos", (req, res) => {
  const db = readDB();
  res.json(db.products);
});

router.post("/productos", (req, res) => {
  const db = readDB();
  const newProduct = { id: Date.now(), ...req.body };
  db.products.push(newProduct);
  saveDB(db);
  res.json(newProduct);
});

router.delete("/productos/:id", (req, res) => {
  const db = readDB();
  db.products = db.products.filter(p => p.id != req.params.id);
  saveDB(db);
  res.json({ ok: true });
});

router.put("/productos/:id", (req, res) => {
  const db = readDB();
  const index = db.products.findIndex(p => p.id == req.params.id);

  if (index === -1) return res.status(404).json({ error: "No existe" });

  db.products[index] = { ...db.products[index], ...req.body };
  saveDB(db);

  res.json(db.products[index]);
});

export default router;
