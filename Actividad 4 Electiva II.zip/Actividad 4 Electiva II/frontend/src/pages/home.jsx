import React from 'react';

export default function Home() {
  return (
    <div>
      <h2>Inicio</h2>
      <p>Proyecto de ejemplo: aplicación web de gestión de inventario (React + API REST).</p>
      <p>Navega a <strong>Productos</strong> para ver la interacción con la API.</p>
    </div>
  );
}
