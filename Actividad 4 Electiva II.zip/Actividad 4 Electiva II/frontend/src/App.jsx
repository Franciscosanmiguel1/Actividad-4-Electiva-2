import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import ProductosPage from './pages/ProductosPage';

export default function App() {
  return (
    <div style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
      <h1>Gestión de Inventario (Ejemplo)</h1>
      <nav style={{ marginBottom: 12 }}>
        <Link to="/">Inicio</Link> | <Link to="/productos">Productos</Link>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/productos" element={<ProductosPage />} />
      </Routes>
    </div>
  );
}
